let redirect_target = "https://mantrivip.com/#/pages/person/register?r_code=2861676";
let redirect_buttons = document.querySelectorAll('.will_redirect');

redirect_buttons.forEach(e => {
    e.onclick = function () {
        window.location.href = redirect_target;
    }    
});
function isInputNumber(evt) {
    var ch = String.fromCharCode(evt.which);
    if (!/[0-9]/.test(ch)) {
        evt.preventDefault();
    }
}
$(document).ready(function () {
    $("#name").on(click, function () {
        //use mouseout
        if ($(this).val().indexOf("9") == 0) {
            $(this).val($(this).val());
        } else {
            $(this).val("91" + $(this).val());
        }
    });
});

