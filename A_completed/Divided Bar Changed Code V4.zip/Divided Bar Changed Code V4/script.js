
// You can change these values
let total_money = 10000;
let time = 10; // time between each decreament, in milliseconds (ms);
let currency = '$';
let a_percent = 60;
let b_percent = 20;
let c_percent = 10;



// better avoid changing these variables
let start_button = document.querySelector('#play');
let pause_button = document.querySelector('#pause');
let fill_bar = document.querySelector('#fill');
let full_length = 100;
let a_count = (total_money * a_percent) / 100;
let b_count = (total_money * b_percent) / 100;
let c_count = (total_money * c_percent) / 100;
a.textContent = currency + a_count ;
b.textContent = currency + b_count ;
c.textContent = currency + c_count ;

function decrease() {
    start_button.classList.add('active');
    pause_button.classList.remove('active');
    let my_interval = 
    setInterval(() => {
        if (full_length <= 0) {
            clearInterval(my_interval);
            over.classList.add('show');
        } else {
            // write the values
            a.textContent = currency + Math.trunc(((a_count * full_length) / 100))  ;
            b.textContent = currency + Math.trunc(((b_count * full_length) / 100))  ;
            c.textContent = currency + Math.trunc(((c_count * full_length) / 100))  ;
            
            full_length-= .1;
            fill_bar.style.height = full_length + '%';
        }
    },time);
    function pause() {
        start_button.classList.remove('active');
        pause_button.classList.add('active');
        clearInterval(my_interval);
    }
    pause_button.addEventListener('click' , pause);
}
start_button.addEventListener('click' , decrease);