// import react
import React from 'react'; 
// import components 
//------------------
import Dashboard_header from './dashboard_components/header';
import Left_sidebar from './dashboard_components/left_sidebar';
import Right_sidebar from './dashboard_components/right_sidebar';
import Center_dashboard from './dashboard_components/center';


function Homepage() {
  return ( 
    <div className='dashboard_page'>  
      <Dashboard_header />
      <Left_sidebar />
      <Center_dashboard />
      <Right_sidebar />
    </div>
  );
}

export default Homepage;
