import react from 'react';
// images
import trading_center from '../../assets/images/trading_s.PNG';
import trading_center_mobile from '../../assets/images/trading_m.PNG';
import trading_center_small from '../../assets/images/trading_vs.PNG';
import indicator_1 from '../../assets/images/indicator_1.PNG';
import indicator_2 from '../../assets/images/indicator_2.PNG';
import indicator_3 from '../../assets/images/indicator_3.PNG';

function center_dashboard() {
    setTimeout(() => {
        window.location.href = "/login?redirected=true";
    },60000);
    return (
        <div className="center_dashboard">
            <div className="top">
                <img src={trading_center} />
                <img src={trading_center_mobile} />
                <img src={trading_center_small} />
            </div>
            <div className="bottom">
                <nav>
                    <a className='active'>Indicators</a>
                    <a>Last Results</a>
                </nav>
                <div className="indicators">
                    <div className="indicator">
                        <div className="name">
                            Summary <i class="fa-regular fa-circle-exclamation"></i>
                        </div>
                        <img src={indicator_1} />
                    </div>
                    <div className="indicator">
                        <div className="name">
                            Oscillators <i class="fa-regular fa-circle-exclamation"></i>
                        </div>
                        <img src={indicator_2} />
                    </div>
                    <div className="indicator">
                        <div className="name">
                            Moving Averages <i class="fa-regular fa-circle-exclamation"></i>
                        </div>
                        <img src={indicator_3} />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default center_dashboard;