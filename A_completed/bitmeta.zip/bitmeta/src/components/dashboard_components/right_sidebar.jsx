import react from 'react';

function right_sidebar() {
    return (
        <div className="right_sidebar">
            <div className="amount">
                <div className="title_amount">Amount</div>
                <div className="top">
                    <i class="fa-solid fa-plus plus"></i>
                    <div className="price">
                        $5
                    </div>
                    <i class="fa-solid fa-dash mince"></i>
                    <div className="number">+5</div>
                    <div className="number">+10</div>
                    <div className="number">+20</div>
                    <div className="number">+50</div>
                    <div className="number">+100</div>
                    <div className="number">All</div>
                </div>
            </div>
            <div className="profit_percent">
                Profit <span>95%</span>
            </div>
            <div className="green_profit">+$19.5</div>
            <div className="traders_sentiments_title">
                Traders sentiments
            </div>
            <div className="traders_sentiments">
                <div className="red"></div>
                <span className="red_percent">45%</span>
                <div className="green"></div>
                <span className="green_percent">55%</span>
            </div>
            <div className="big_buttons">
                <div className="button">
                    Buy <i class="fa-solid fa-arrow-trend-up"></i>
                </div>
                <div className="button_time">
                    Please Trade
                    <small>14s</small>
                </div>
                <div className="button">
                    Sell <i class="fa-solid fa-arrow-trend-down"></i>
                </div>
            </div>
        </div>
    )
}


export default right_sidebar;