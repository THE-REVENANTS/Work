
<h3>footer</h3>
<?php wp_footer(); ?>
</body>
</html>