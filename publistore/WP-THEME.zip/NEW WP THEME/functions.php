<?php
/*-
-- I linked all my files in this functions.php
-- Starting with the css file here :
-*/
function mr_add_styles() {
    wp_enqueue_style('my-style', get_template_directory_uri() . '/assets/css/main.css');
}
/*-
-- I linked all my files in this functions.php
-- Then the javascript file here :
-*/
function mr_add_script() {
    wp_enqueue_script('my-script', get_template_directory_uri() . '/assets/js/script.js', array(), false, true);
}


add_action('wp_enqueue_scripts', 'mr_add_styles');
add_action('wp_enqueue_scripts', 'mr_add_script');